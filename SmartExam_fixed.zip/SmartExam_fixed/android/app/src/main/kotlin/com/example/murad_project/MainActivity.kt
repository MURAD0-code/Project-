package com.example.murad_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
