import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:smart_exam/main.dart';

void main() {
  testWidgets('App launches and shows the login screen', (tester) async {
    await tester.pumpWidget(const SmartExamApp());

    expect(find.text('تسجيل الدخول - SmartExam'), findsOneWidget);
    expect(find.byType(Image), findsOneWidget);
    expect(find.byType(TextFormField), findsNWidgets(2));
    expect(find.text('نسيت كلمة المرور؟'), findsOneWidget);
    expect(find.text('لا تمتلك حسابًا؟ أنشئ حسابًا جديدًا'), findsOneWidget);
  });

  testWidgets('Login validation rejects empty fields', (tester) async {
    await tester.pumpWidget(const SmartExamApp());

    await tester.tap(find.text('تسجيل الدخول'));
    await tester.pump();

    expect(find.text('البريد الإلكتروني مطلوب'), findsOneWidget);
    expect(find.text('كلمة المرور مطلوبة'), findsOneWidget);
  });
}
