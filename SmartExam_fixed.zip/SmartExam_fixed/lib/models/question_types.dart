import 'dart:convert';

/// أنواع الأسئلة المدعومة في بنك الأسئلة.
class QuestionType {
  QuestionType._();

  static const String text = 'text';
  static const String mcq = 'mcq';
  static const String trueFalse = 'tf';

  static const String trueLabel = 'صح';
  static const String falseLabel = 'خطأ';

  static const List<String> all = [mcq, trueFalse, text];
  static const List<String> levels = ['سهل', 'متوسط', 'صعب'];

  static String label(String? type) {
    switch (type) {
      case mcq:
        return 'اختيار من متعدد';
      case trueFalse:
        return 'صح / خطأ';
      default:
        return 'إجابة نصية';
    }
  }

  static String normalizeType(String? type) => all.contains(type) ? type! : text;

  /// يقبل List (مسودة) أو نص JSON (من قاعدة البيانات) أو null.
  static List<String> parseOptions(dynamic raw) {
    try {
      dynamic value = raw;
      if (value is String) {
        if (value.trim().isEmpty) return [];
        value = jsonDecode(value);
      }
      if (value is List) {
        return value
            .map((e) => e.toString().trim())
            .where((e) => e.isNotEmpty)
            .toList();
      }
    } catch (_) {}
    return [];
  }

  static String? encodeOptions(List<String> options) =>
      options.isEmpty ? null : jsonEncode(options);
}
