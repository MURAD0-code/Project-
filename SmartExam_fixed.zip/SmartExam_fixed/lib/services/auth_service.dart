import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

class AuthFailure implements Exception {
  final String message;
  const AuthFailure(this.message);

  @override
  String toString() => message;
}

/// غلاف بسيط حول Firebase Authentication.
class AuthService {
  AuthService._();

  static final AuthService instance = AuthService._();

  bool _ready = false;
  bool get isReady => _ready;

  /// يُستدعى مرة واحدة عند بدء التطبيق. لا يرمي خطأ إذا لم يُعدّ Firebase بعد.
  Future<void> init() async {
    try {
      await Firebase.initializeApp();
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  /// معرّف المستخدم الحالي (uid) أو null إذا لم يسجّل الدخول.
  String? get currentUid => _ready ? FirebaseAuth.instance.currentUser?.uid : null;

  FirebaseAuth get _auth {
    if (!_ready) {
      throw const AuthFailure(
        'لم يتم إعداد Firebase بعد. أضف ملف google-services.json داخل android/app ثم أعد تشغيل التطبيق.',
      );
    }
    return FirebaseAuth.instance;
  }

  Future<void> signIn(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(_message(e));
    }
  }

  /// ينشئ الحساب. Firebase يسجّل دخول المستخدم تلقائيًا بعد الإنشاء.
  Future<void> signUp(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(email: email, password: password);
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(_message(e));
    }
  }

  /// يرسل رابط إعادة تعيين كلمة المرور إلى البريد.
  Future<void> sendPasswordReset(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(_message(e));
    }
  }

  Future<void> signOut() async {
    if (!_ready) return;
    await FirebaseAuth.instance.signOut();
  }

  String _message(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'صيغة البريد الإلكتروني غير صحيحة.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
      case 'invalid-login-credentials':
        return 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
      case 'user-disabled':
        return 'تم تعطيل هذا الحساب.';
      case 'too-many-requests':
        return 'محاولات كثيرة. حاول مرة أخرى بعد قليل.';
      case 'network-request-failed':
        return 'لا يوجد اتصال بالإنترنت.';
      case 'email-already-in-use':
        return 'البريد الإلكتروني مسجل مسبقًا.';
      case 'weak-password':
        return 'كلمة المرور ضعيفة. استخدم 6 أحرف على الأقل.';
      case 'operation-not-allowed':
        return 'تسجيل الدخول بالبريد غير مفعّل في Firebase Console (Authentication ‏> Sign-in method).';
      default:
        return 'حدث خطأ غير متوقع (${e.code}).';
    }
  }
}
