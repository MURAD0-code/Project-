import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../database/database_helper.dart';
import '../models/question_types.dart';

/// اسم النموذج المستخدم. أسماء نماذج Gemini تتغير بمرور الوقت؛ إذا ظهرت رسالة
/// "النموذج غير متاح" فغيّر هذه القيمة إلى اسم نموذج Flash حالي من
/// https://ai.google.dev/gemini-api/docs/models
const String kGeminiModel = 'gemini-3.8-flash';

/// أقصى حجم لملف PDF يُرسل مباشرة داخل الطلب.
const int kMaxPdfBytes = 20 * 1024 * 1024;

class GeminiException implements Exception {
  final String message;
  const GeminiException(this.message);

  @override
  String toString() => message;
}

class ExtractedQuestion {
  final String text;
  final String type;
  final List<String> options;
  final String answer;
  final String level;

  /// false => الملف لا يحتوي الإجابة، والنموذج هو من اقترحها (تحتاج مراجعة).
  final bool answerFromDocument;

  const ExtractedQuestion({
    required this.text,
    required this.type,
    required this.options,
    required this.answer,
    required this.level,
    required this.answerFromDocument,
  });

  Map<String, dynamic> toMap() => {
        'text': text,
        'type': type,
        'options': options,
        'answer': answer,
        'level': level,
      };
}

class ExtractionResult {
  /// 'lecture' أو 'questions'
  final String sourceType;
  final List<ExtractedQuestion> questions;

  /// عدد الأسئلة التي تجاهلناها لأن بياناتها غير صالحة.
  final int skipped;

  const ExtractionResult({
    required this.sourceType,
    required this.questions,
    required this.skipped,
  });
}

class GeminiService {
  GeminiService._();

  static final GeminiService instance = GeminiService._();

  static const String _keyName = 'gemini_api_key';

  final FlutterSecureStorage _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  Future<String?> getApiKey() async {
    final key = await _storage.read(key: _keyName);
    return (key == null || key.trim().isEmpty) ? null : key.trim();
  }

  Future<void> saveApiKey(String key) => _storage.write(key: _keyName, value: key.trim());

  Future<void> deleteApiKey() => _storage.delete(key: _keyName);

  Future<ExtractionResult> extractFromPdf({
    required File pdf,
    int lectureQuestionCount = 10,
  }) async {
    final apiKey = await getApiKey();
    if (apiKey == null) {
      throw const GeminiException('أدخل مفتاح Gemini API أولًا.');
    }

    final length = await pdf.length();
    if (length > kMaxPdfBytes) {
      throw const GeminiException('حجم الملف أكبر من 20 ميجابايت. قسّمه إلى ملفات أصغر ثم أعد المحاولة.');
    }
    final base64Pdf = base64Encode(await pdf.readAsBytes());
    final prompt = _buildPrompt(lectureQuestionCount);

    http.Response response;
    try {
      response = await _send(apiKey, base64Pdf, prompt, useSchema: true);
      // بعض الإصدارات ترفض المخطط؛ نعيد المحاولة بدونه (الوصف موجود داخل الطلب النصي).
      if (response.statusCode == 400 && utf8.decode(response.bodyBytes).toLowerCase().contains('schema')) {
        response = await _send(apiKey, base64Pdf, prompt, useSchema: false);
      }
    } on SocketException {
      throw const GeminiException('لا يوجد اتصال بالإنترنت.');
    } on TimeoutException {
      throw const GeminiException('انتهت مهلة الطلب. جرّب ملفًا أصغر أو أعد المحاولة.');
    } on http.ClientException {
      throw const GeminiException('تعذر الاتصال بخدمة Gemini. تحقق من الإنترنت.');
    }

    if (response.statusCode != 200) {
      throw GeminiException(_httpErrorMessage(response));
    }

    return _parseResponse(utf8.decode(response.bodyBytes));
  }

  Future<http.Response> _send(
    String apiKey,
    String base64Pdf,
    String prompt, {
    required bool useSchema,
  }) {
    final uri = Uri.https(
      'generativelanguage.googleapis.com',
      '/v1beta/models/$kGeminiModel:generateContent',
    );

    final generationConfig = <String, dynamic>{
      'responseMimeType': 'application/json',
      if (useSchema) 'responseSchema': _schema,
    };

    final body = jsonEncode({
      'contents': [
        {
          'role': 'user',
          'parts': [
            {
              'inline_data': {'mime_type': 'application/pdf', 'data': base64Pdf},
            },
            {'text': prompt},
          ],
        },
      ],
      'generationConfig': generationConfig,
    });

    return http
        .post(
          uri,
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': apiKey,
          },
          body: body,
        )
        .timeout(const Duration(seconds: 180));
  }

  String _httpErrorMessage(http.Response response) {
    String detail = '';
    try {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      detail = decoded['error']?['message']?.toString() ?? '';
    } catch (_) {}

    final lower = detail.toLowerCase();
    switch (response.statusCode) {
      case 400:
        if (lower.contains('api key')) return 'مفتاح Gemini غير صحيح.';
        return 'رفضت الخدمة الطلب: $detail';
      case 401:
      case 403:
        return 'مفتاح Gemini غير مصرّح له أو غير مفعّل. تأكد منه وأعد المحاولة.';
      case 404:
        return 'النموذج $kGeminiModel غير متاح. غيّر الثابت kGeminiModel في gemini_service.dart إلى نموذج حالي.';
      case 429:
        return 'تجاوزت حد الاستخدام. انتظر قليلًا ثم أعد المحاولة.';
      default:
        if (response.statusCode >= 500) {
          return 'خدمة Gemini مشغولة حاليًا. أعد المحاولة بعد قليل.';
        }
        return 'خطأ من الخدمة (${response.statusCode}): $detail';
    }
  }

  ExtractionResult _parseResponse(String body) {
    final dynamic decoded = jsonDecode(body);

    final feedback = decoded['promptFeedback'];
    if (feedback is Map && feedback['blockReason'] != null) {
      throw GeminiException('رفض النموذج معالجة الملف (${feedback['blockReason']}).');
    }

    final candidates = decoded['candidates'];
    if (candidates is! List || candidates.isEmpty) {
      throw const GeminiException('لم يُرجع النموذج أي نتيجة. جرّب ملفًا آخر.');
    }

    final parts = candidates.first['content']?['parts'];
    final buffer = StringBuffer();
    if (parts is List) {
      for (final part in parts) {
        if (part is Map && part['thought'] != true && part['text'] != null) {
          buffer.write(part['text']);
        }
      }
    }

    var raw = buffer.toString().trim();
    if (raw.isEmpty) {
      throw const GeminiException('الرد فارغ. قد يكون الملف غير مقروء أو محميًا.');
    }
    raw = raw.replaceAll(RegExp(r'^```(?:json)?\s*', multiLine: false), '').replaceAll(RegExp(r'\s*```$'), '');

    dynamic json;
    try {
      json = jsonDecode(raw);
    } catch (_) {
      throw const GeminiException('تعذر قراءة رد النموذج (صيغة غير صالحة). أعد المحاولة.');
    }

    List<dynamic> rawQuestions;
    String sourceType = 'lecture';
    if (json is Map) {
      sourceType = json['source_type']?.toString() == 'questions' ? 'questions' : 'lecture';
      rawQuestions = json['questions'] is List ? json['questions'] as List : [];
    } else if (json is List) {
      rawQuestions = json;
    } else {
      rawQuestions = [];
    }

    final questions = <ExtractedQuestion>[];
    var skipped = 0;
    for (final item in rawQuestions) {
      final q = item is Map ? _parseQuestion(Map<String, dynamic>.from(item)) : null;
      if (q == null) {
        skipped++;
      } else {
        questions.add(q);
      }
    }

    if (questions.isEmpty) {
      throw const GeminiException('لم يتم العثور على أسئلة صالحة في الملف.');
    }
    return ExtractionResult(sourceType: sourceType, questions: questions, skipped: skipped);
  }

  ExtractedQuestion? _parseQuestion(Map<String, dynamic> json) {
    final text = (json['text'] ?? '').toString().trim();
    final rawAnswer = (json['answer'] ?? '').toString().trim();
    if (text.isEmpty || rawAnswer.isEmpty) return null;

    var type = QuestionType.normalizeType(json['type']?.toString().trim());
    final options = <String>[];
    if (json['options'] is List) {
      final seen = <String>{};
      for (final o in json['options'] as List) {
        final value = o.toString().trim();
        if (value.isNotEmpty && seen.add(DatabaseHelper.normalizeAnswer(value))) {
          options.add(value);
        }
      }
    }

    String answer;
    if (type == QuestionType.mcq) {
      if (options.length < 2) return null;
      final matched = _matchOption(rawAnswer, options);
      if (matched == null) return null;
      answer = matched;
    } else if (type == QuestionType.trueFalse) {
      final tf = _normalizeTrueFalse(rawAnswer);
      if (tf == null) return null;
      answer = tf;
      options.clear();
    } else {
      type = QuestionType.text;
      answer = rawAnswer;
      options.clear();
    }

    final level = json['level']?.toString().trim() ?? '';
    return ExtractedQuestion(
      text: text,
      type: type,
      options: options,
      answer: answer,
      level: QuestionType.levels.contains(level) ? level : 'متوسط',
      answerFromDocument: json['answer_from_document'] != false,
    );
  }

  String? _matchOption(String answer, List<String> options) {
    final normalized = DatabaseHelper.normalizeAnswer(answer);
    for (final option in options) {
      if (DatabaseHelper.normalizeAnswer(option) == normalized) return option;
    }

    // أحيانًا يرجع النموذج حرف الخيار (أ / ب / A / B) أو رقمه بدل نصه
    final cleaned = normalized.replaceAll(RegExp(r'[\s\.\)\(\-:]'), '');
    const arabic = ['أ', 'ب', 'ج', 'د', 'هـ', 'و'];
    const latin = ['a', 'b', 'c', 'd', 'e', 'f'];
    var index = arabic.indexOf(cleaned);
    if (index < 0) index = latin.indexOf(cleaned);
    if (index < 0) {
      final number = int.tryParse(cleaned);
      if (number != null) index = number - 1;
    }
    if (index >= 0 && index < options.length) return options[index];
    return null;
  }

  String? _normalizeTrueFalse(String answer) {
    final value = answer.trim().toLowerCase();
    const yes = {'صح', 'صحيح', 'true', 't', 'yes', 'correct', 'نعم'};
    const no = {'خطأ', 'خطا', 'خاطئ', 'false', 'f', 'no', 'incorrect', 'لا'};
    if (yes.contains(value)) return QuestionType.trueLabel;
    if (no.contains(value)) return QuestionType.falseLabel;
    return null;
  }

  static const Map<String, dynamic> _schema = {
    'type': 'OBJECT',
    'properties': {
      'source_type': {
        'type': 'STRING',
        'enum': ['lecture', 'questions'],
      },
      'questions': {
        'type': 'ARRAY',
        'items': {
          'type': 'OBJECT',
          'properties': {
            'text': {'type': 'STRING'},
            'type': {
              'type': 'STRING',
              'enum': ['mcq', 'tf', 'text'],
            },
            'options': {
              'type': 'ARRAY',
              'items': {'type': 'STRING'},
            },
            'answer': {'type': 'STRING'},
            'level': {
              'type': 'STRING',
              'enum': ['سهل', 'متوسط', 'صعب'],
            },
            'answer_from_document': {'type': 'BOOLEAN'},
          },
          'required': ['text', 'type', 'options', 'answer', 'level', 'answer_from_document'],
        },
      },
    },
    'required': ['source_type', 'questions'],
  };

  String _buildPrompt(int lectureQuestionCount) => '''
You are an expert exam writer for university students.
The attached PDF is either:
(A) lecture / study material, or
(B) a document that already contains exam questions (a question paper, quiz or worksheet, with or without an answer key).
Decide which one it is and set "source_type" to "lecture" or "questions".

If it is lecture material (A):
- Write exactly $lectureQuestionCount NEW questions that cover the most important concepts, spread across the whole document.
- Use only the types "mcq" (exactly 4 options) and "tf" (true/false): about 70% "mcq" and 30% "tf".
- Mix the difficulty levels. Base every question strictly on the document content; do not add outside facts.
- Set "answer_from_document" to true.

If it already contains questions (B):
- Extract EVERY question in the document, completely and faithfully, keeping the original wording and language.
- Keep the original type: "mcq" if choices are listed, "tf" if it is true/false, otherwise "text" (short answer / essay).
- Take the answer from the document's answer key or from the marked correct choice and set "answer_from_document" to true.
- If the document gives no answer for a question, give the most likely correct answer yourself and set "answer_from_document" to false.
- Do NOT invent questions that are not in the document.

Rules for both cases:
- Write in the same language as the document.
- "options": for "mcq" list only the option texts, without letter or number prefixes (no "A)", "أ-", "1."). Use an empty list for "tf" and "text".
- "answer": for "mcq" it must be exactly identical to one of the options; for "tf" it must be exactly "صح" or "خطأ"; for "text" a concise correct answer.
- "level" must be one of: "سهل", "متوسط", "صعب".
- Do not put the question number inside the question text.

Return ONLY JSON in this shape:
{"source_type":"lecture|questions","questions":[{"text":"...","type":"mcq|tf|text","options":["..."],"answer":"...","level":"سهل|متوسط|صعب","answer_from_document":true}]}
''';
}
