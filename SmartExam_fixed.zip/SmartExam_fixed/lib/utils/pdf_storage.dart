import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// ملفات الـ PDF التي يختارها المستخدم تكون في مجلد مؤقت (cache) قد يُحذف،
/// لذلك ننسخها إلى مجلد دائم داخل التطبيق قبل حفظ مسارها في قاعدة البيانات.
class PdfStorage {
  PdfStorage._();

  static Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(base.path, 'pdfs'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// يعيد المسار الدائم للملف (ينسخه إذا لم يكن داخل مجلد التطبيق).
  static Future<String> persist(String sourcePath) async {
    final dir = await _dir();
    if (p.isWithin(dir.path, sourcePath)) return sourcePath;
    final name = '${DateTime.now().millisecondsSinceEpoch}_${p.basename(sourcePath)}';
    final target = p.join(dir.path, name);
    await File(sourcePath).copy(target);
    return target;
  }
}
