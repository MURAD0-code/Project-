import 'dart:convert';
import 'package:crypto/crypto.dart';

class SecurityHelper {
  static String hashPassword(String password) {
    final String salt = "SmartExam_Salt_2026!";
    final bytes = utf8.encode(password + salt);
    return sha256.convert(bytes).toString();
  }
}
