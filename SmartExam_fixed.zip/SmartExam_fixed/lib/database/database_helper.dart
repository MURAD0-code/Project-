import 'dart:convert';
import 'dart:math';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';

import '../models/question_types.dart';

class DatabaseHelper {
  DatabaseHelper._init();

  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('smart_exam_app.db');
    return _database!;
  }

  Future<String> _getEncryptionKey() async {
    String? key = await _secureStorage.read(key: 'db_key');
    if (key != null && key.isNotEmpty) return key;

    final random = Random.secure();
    key = base64UrlEncode(
      List<int>.generate(32, (_) => random.nextInt(256)),
    );
    await _secureStorage.write(key: 'db_key', value: key);
    return key;
  }

  Future<Database> _initDB(String fileName) async {
    final dbDirectory = await getDatabasesPath();
    final dbPath = join(dbDirectory, fileName);
    final key = await _getEncryptionKey();

    return openDatabase(
      dbPath,
      version: 3,
      password: key,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _createDB,
      onUpgrade: _upgradeDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE exams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        subject TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        exam_id INTEGER NOT NULL,
        text TEXT NOT NULL,
        answer TEXT NOT NULL,
        level TEXT NOT NULL,
        pdf_path TEXT,
        type TEXT NOT NULL DEFAULT 'text',
        options TEXT,
        FOREIGN KEY (exam_id) REFERENCES exams (id) ON DELETE CASCADE
      )
    ''');

    await _createAttemptTables(db);
    await _insertDemoExams(db);
  }

  Future<void> _upgradeDB(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await _createAttemptTables(db);
    }
    if (oldVersion < 3) {
      // أنواع الأسئلة: text / mcq / tf (options تُخزَّن كنص JSON)
      await db.execute("ALTER TABLE questions ADD COLUMN type TEXT NOT NULL DEFAULT 'text'");
      await db.execute('ALTER TABLE questions ADD COLUMN options TEXT');
    }
  }

  Future<void> _createAttemptTables(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        exam_id INTEGER NOT NULL,
        exam_title TEXT NOT NULL,
        total_questions INTEGER NOT NULL,
        correct_answers INTEGER NOT NULL,
        percentage REAL NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS attempt_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        attempt_id INTEGER NOT NULL,
        question_id INTEGER NOT NULL,
        question_text TEXT NOT NULL,
        correct_answer TEXT NOT NULL,
        selected_answer TEXT NOT NULL,
        is_correct INTEGER NOT NULL,
        FOREIGN KEY (attempt_id) REFERENCES attempts (id) ON DELETE CASCADE
      )
    ''');
  }

  Future<void> _insertDemoExams(Database db) async {
    await db.insert('exams', {
      'title': 'برمجة التطبيقات Dart',
      'subject': 'تطوير الهواتف',
    });
    await db.insert('exams', {
      'title': 'قواعد البيانات SQLite',
      'subject': 'إدارة البيانات',
    });
  }

  Future<List<Map<String, dynamic>>> getExams() async {
    final db = await database;
    return db.query('exams', orderBy: 'id ASC');
  }

  Future<int> addExam(String title, String subject) async {
    final db = await database;
    return db.insert('exams', {
      'title': title,
      'subject': subject,
    });
  }

  Future<int> updateExam(int id, String title, String subject) async {
    final db = await database;
    return db.update(
      'exams',
      {'title': title, 'subject': subject},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteExam(int id) async {
    final db = await database;
    return db.delete('exams', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> getQuestionsByExam(int examId) async {
    final db = await database;
    return db.query(
      'questions',
      where: 'exam_id = ?',
      whereArgs: [examId],
      orderBy: 'id ASC',
    );
  }

  Future<int> getQuestionCountForExam(int examId) async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS count FROM questions WHERE exam_id = ?',
      [examId],
    );
    return (rows.first['count'] as num?)?.toInt() ?? 0;
  }

  Future<List<Map<String, dynamic>>> getRandomQuestions(
    int examId,
    int limit,
  ) async {
    if (limit <= 0) return [];
    final db = await database;
    return db.rawQuery(
      'SELECT id, exam_id, text, answer, level, pdf_path, type, options '
      'FROM questions WHERE exam_id = ? ORDER BY RANDOM() LIMIT ?',
      [examId, limit],
    );
  }

  Future<int> addQuestion(
    int examId,
    String text,
    String answer,
    String level,
    String? pdfPath, {
    String type = QuestionType.text,
    List<String> options = const [],
  }) async {
    final db = await database;
    return db.insert('questions', {
      'exam_id': examId,
      'text': text,
      'answer': answer,
      'level': level,
      'pdf_path': pdfPath ?? '',
      'type': QuestionType.normalizeType(type),
      'options': QuestionType.encodeOptions(options),
    });
  }

  /// يحفظ مجموعة أسئلة دفعة واحدة (مثل الأسئلة المستخرجة من PDF)،
  /// ويتجاهل الأسئلة المكررة (نفس النص داخل نفس الاختبار).
  /// يعيد {'inserted': عدد المحفوظ, 'duplicates': عدد المتجاهل}.
  Future<Map<String, int>> addQuestionsBatch(
    int examId,
    List<Map<String, dynamic>> questions,
  ) async {
    final db = await database;
    return db.transaction<Map<String, int>>((txn) async {
      final existing = await txn.query(
        'questions',
        columns: ['text'],
        where: 'exam_id = ?',
        whereArgs: [examId],
      );
      final seen = existing
          .map((row) => normalizeAnswer(row['text']?.toString() ?? ''))
          .toSet();

      int inserted = 0;
      int duplicates = 0;
      for (final q in questions) {
        final text = q['text'].toString().trim();
        final key = normalizeAnswer(text);
        if (seen.contains(key)) {
          duplicates++;
          continue;
        }
        seen.add(key);
        await txn.insert('questions', {
          'exam_id': examId,
          'text': text,
          'answer': q['answer'].toString().trim(),
          'level': q['level']?.toString() ?? 'متوسط',
          'pdf_path': q['pdf_path']?.toString() ?? '',
          'type': QuestionType.normalizeType(q['type']?.toString()),
          'options': QuestionType.encodeOptions(
            QuestionType.parseOptions(q['options']),
          ),
        });
        inserted++;
      }
      return {'inserted': inserted, 'duplicates': duplicates};
    });
  }

  Future<int> updateQuestion(
    int id,
    String text,
    String answer,
    String level,
    String? pdfPath, {
    String type = QuestionType.text,
    List<String> options = const [],
  }) async {
    final db = await database;
    return db.update(
      'questions',
      {
        'text': text,
        'answer': answer,
        'level': level,
        'pdf_path': pdfPath ?? '',
        'type': QuestionType.normalizeType(type),
        'options': QuestionType.encodeOptions(options),
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteQuestion(int id) async {
    final db = await database;
    return db.delete('questions', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> getTotalQuestionsCount() async {
    final db = await database;
    final rows = await db.rawQuery('SELECT COUNT(*) AS count FROM questions');
    return (rows.first['count'] as num?)?.toInt() ?? 0;
  }

  Future<int> getAttemptsCount() async {
    final db = await database;
    final rows = await db.rawQuery('SELECT COUNT(*) AS count FROM attempts');
    return (rows.first['count'] as num?)?.toInt() ?? 0;
  }

  Future<double> getAveragePercentage() async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT AVG(percentage) AS average FROM attempts',
    );
    return (rows.first['average'] as num?)?.toDouble() ?? 0;
  }

  Future<int> saveAttempt({
    required int examId,
    required String examTitle,
    required List<Map<String, dynamic>> questions,
    required Map<int, String> answers,
  }) async {
    if (questions.isEmpty) {
      throw StateError('لا توجد أسئلة لحفظ المحاولة');
    }

    final db = await database;
    return db.transaction<int>((txn) async {
      int correctAnswers = 0;
      final evaluations = <Map<String, dynamic>>[];

      for (final question in questions) {
        final int questionId = (question['id'] as num).toInt();
        final String questionText = question['text']?.toString() ?? '';
        final String correctAnswer = question['answer']?.toString() ?? '';
        final String selectedAnswer = answers[questionId]?.trim() ?? '';
        final bool isCorrect = normalizeAnswer(selectedAnswer) ==
            normalizeAnswer(correctAnswer);

        if (isCorrect) correctAnswers++;

        evaluations.add({
          'question_id': questionId,
          'question_text': questionText,
          'correct_answer': correctAnswer,
          'selected_answer': selectedAnswer,
          'is_correct': isCorrect ? 1 : 0,
        });
      }

      final percentage = (correctAnswers / questions.length) * 100;
      final attemptId = await txn.insert('attempts', {
        'exam_id': examId,
        'exam_title': examTitle,
        'total_questions': questions.length,
        'correct_answers': correctAnswers,
        'percentage': percentage,
        'created_at': DateTime.now().toIso8601String(),
      });

      for (final evaluation in evaluations) {
        await txn.insert('attempt_answers', {
          'attempt_id': attemptId,
          ...evaluation,
        });
      }

      return attemptId;
    });
  }

  Future<List<Map<String, dynamic>>> getAttempts({int? limit}) async {
    final db = await database;
    return db.query(
      'attempts',
      orderBy: 'created_at DESC',
      limit: limit,
    );
  }

  Future<List<Map<String, dynamic>>> getWeakQuestions({int limit = 10}) async {
    final db = await database;
    return db.rawQuery('''
      SELECT
        question_id,
        question_text,
        COUNT(*) AS attempts_count,
        SUM(CASE WHEN is_correct = 0 THEN 1 ELSE 0 END) AS wrong_count,
        ROUND(
          (SUM(CASE WHEN is_correct = 0 THEN 1 ELSE 0 END) * 100.0) /
          COUNT(*),
          1
        ) AS error_rate
      FROM attempt_answers
      GROUP BY question_id, question_text
      HAVING COUNT(*) > 0
      ORDER BY error_rate DESC, attempts_count DESC
      LIMIT ?
    ''', [limit]);
  }

  Future<Map<String, dynamic>?> getAttempt(int attemptId) async {
    final db = await database;
    final attempts = await db.query(
      'attempts',
      where: 'id = ?',
      whereArgs: [attemptId],
      limit: 1,
    );
    if (attempts.isEmpty) return null;

    final answers = await db.query(
      'attempt_answers',
      where: 'attempt_id = ?',
      whereArgs: [attemptId],
      orderBy: 'id ASC',
    );

    return {
      'attempt': attempts.first,
      'answers': answers,
    };
  }

  static String normalizeAnswer(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');
  }

  Future<void> close() async {
    final db = _database;
    if (db == null) return;
    await db.close();
    _database = null;
  }
}
