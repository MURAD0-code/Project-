import 'package:flutter/material.dart';

/// خيار واحد قابل للاختيار (بديل بسيط عن RadioListTile).
class ChoiceTile extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback? onTap;

  const ChoiceTile({
    super.key,
    required this.label,
    required this.selected,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: Icon(
        selected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
        color: selected ? color : Colors.grey,
      ),
      title: Text(label),
      onTap: onTap,
    );
  }
}
