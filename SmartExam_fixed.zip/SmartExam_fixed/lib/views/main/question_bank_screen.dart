import 'package:flutter/material.dart';

import '../../database/database_helper.dart';
import '../../models/question_types.dart';
import 'add_question_screen.dart';
import 'pdf_import_screen.dart';

class QuestionBankScreen extends StatefulWidget {
  const QuestionBankScreen({super.key});

  @override
  State<QuestionBankScreen> createState() => _QuestionBankScreenState();
}

class _QuestionBankScreenState extends State<QuestionBankScreen> {
  List<Map<String, dynamic>> _exams = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadExams();
  }

  Future<void> _loadExams() async {
    try {
      final data = await DatabaseHelper.instance.getExams();
      if (!mounted) return;
      setState(() {
        _exams = data;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      _showError('تعذر تحميل الاختبارات: $e');
    }
  }

  Future<void> _addExamDialog() async {
    final titleController = TextEditingController();
    final subjectController = TextEditingController();
    final dialogFormKey = GlobalKey<FormState>();

    try {
      final saved = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('إضافة اختبار جديد'),
          content: Form(
            key: dialogFormKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: titleController,
                  decoration: const InputDecoration(labelText: 'عنوان الاختبار', border: OutlineInputBorder()),
                  validator: (value) => value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: subjectController,
                  decoration: const InputDecoration(labelText: 'المادة/التصنيف', border: OutlineInputBorder()),
                  validator: (value) => value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () async {
                if (!dialogFormKey.currentState!.validate()) return;
                try {
                  final id = await DatabaseHelper.instance.addExam(
                    titleController.text.trim(),
                    subjectController.text.trim(),
                  );
                  if (id > 0 && context.mounted) Navigator.pop(context, true);
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('تعذر إضافة الاختبار: $e'), backgroundColor: Colors.red),
                    );
                  }
                }
              },
              child: const Text('إضافة'),
            ),
          ],
        ),
      );

      if (saved == true) {
        await _loadExams();
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تمت إضافة الاختبار بنجاح'), backgroundColor: Colors.green),
        );
      }
    } finally {
      titleController.dispose();
      subjectController.dispose();
    }
  }

  Future<void> _editExam(Map<String, dynamic> exam) async {
    final titleController = TextEditingController(text: exam['title'].toString());
    final subjectController = TextEditingController(text: exam['subject'].toString());
    final dialogFormKey = GlobalKey<FormState>();

    try {
      final saved = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('تعديل الاختبار'),
          content: Form(
            key: dialogFormKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: titleController,
                  decoration: const InputDecoration(labelText: 'عنوان الاختبار', border: OutlineInputBorder()),
                  validator: (value) => value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: subjectController,
                  decoration: const InputDecoration(labelText: 'المادة/التصنيف', border: OutlineInputBorder()),
                  validator: (value) => value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () async {
                if (!dialogFormKey.currentState!.validate()) return;
                try {
                  final affected = await DatabaseHelper.instance.updateExam(
                    (exam['id'] as num).toInt(),
                    titleController.text.trim(),
                    subjectController.text.trim(),
                  );
                  if (affected == 1 && context.mounted) Navigator.pop(context, true);
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('تعذر تعديل الاختبار: $e'), backgroundColor: Colors.red),
                    );
                  }
                }
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      );

      if (saved == true) {
        await _loadExams();
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم تعديل الاختبار بنجاح'), backgroundColor: Colors.green),
        );
      }
    } finally {
      titleController.dispose();
      subjectController.dispose();
    }
  }

  Future<void> _deleteExam(int examId, String title) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد حذف الاختبار'),
        content: Text('سيتم حذف الاختبار وجميع أسئلته: $title. هل تريد المتابعة؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('حذف', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      final affected = await DatabaseHelper.instance.deleteExam(examId);
      if (!mounted) return;
      if (affected == 1) {
        await _loadExams();
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم حذف الاختبار وجميع أسئلته')),
        );
      }
    } catch (e) {
      _showError('تعذر حذف الاختبار: $e');
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('بنك الاختبارات'),
        actions: [
          IconButton(onPressed: _loadExams, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(12),
              child: _exams.isEmpty
                  ? const Center(child: Text('لا توجد اختبارات مضافة حاليًا'))
                  : GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 1.05,
                      ),
                      itemCount: _exams.length,
                      itemBuilder: (context, index) {
                        final exam = _exams[index];
                        final id = (exam['id'] as num).toInt();
                        return Card(
                          elevation: 4,
                          color: Colors.blue[50],
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(15),
                            onTap: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ExamQuestionsDetailScreen(
                                    examId: id,
                                    examTitle: exam['title'].toString(),
                                  ),
                                ),
                              );
                              _loadExams();
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                children: [
                                  Align(
                                    alignment: Alignment.topLeft,
                                    child: PopupMenuButton<String>(
                                      onSelected: (value) {
                                        if (value == 'edit') _editExam(exam);
                                        if (value == 'delete') _deleteExam(id, exam['title'].toString());
                                      },
                                      itemBuilder: (_) => const [
                                        PopupMenuItem(value: 'edit', child: Text('تعديل')),
                                        PopupMenuItem(value: 'delete', child: Text('حذف')),
                                      ],
                                    ),
                                  ),
                                  const Spacer(),
                                  Icon(Icons.folder_special, size: 46, color: Colors.blue[800]),
                                  const SizedBox(height: 8),
                                  Text(
                                    exam['title'].toString(),
                                    textAlign: TextAlign.center,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    exam['subject'].toString(),
                                    textAlign: TextAlign.center,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(color: Colors.grey[700], fontSize: 12),
                                  ),
                                  const Spacer(),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addExamDialog,
        tooltip: 'إضافة اختبار جديد',
        child: const Icon(Icons.add),
      ),
    );
  }
}

class ExamQuestionsDetailScreen extends StatefulWidget {
  final int examId;
  final String examTitle;

  const ExamQuestionsDetailScreen({
    super.key,
    required this.examId,
    required this.examTitle,
  });

  @override
  State<ExamQuestionsDetailScreen> createState() => _ExamQuestionsDetailScreenState();
}

class _ExamQuestionsDetailScreenState extends State<ExamQuestionsDetailScreen> {
  List<Map<String, dynamic>> _questions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadQuestions();
  }

  Future<void> _loadQuestions() async {
    try {
      final data = await DatabaseHelper.instance.getQuestionsByExam(widget.examId);
      if (!mounted) return;
      setState(() {
        _questions = data;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تحميل الأسئلة: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _deleteQuestion(int id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: const Text('هل أنت متأكد من حذف هذا السؤال؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('حذف', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      final affected = await DatabaseHelper.instance.deleteQuestion(id);
      if (!mounted) return;
      if (affected == 1) {
        await _loadQuestions();
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم حذف السؤال بنجاح')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر حذف السؤال: $e'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.examTitle),
        actions: [IconButton(onPressed: _loadQuestions, icon: const Icon(Icons.refresh))],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _questions.isEmpty
              ? const Center(child: Text('لا توجد أسئلة مضافة لهذا الاختبار'))
              : ListView.builder(
                  padding: const EdgeInsets.all(10),
                  itemCount: _questions.length,
                  itemBuilder: (context, index) {
                    final q = _questions[index];
                    final pdfPath = q['pdf_path']?.toString() ?? '';
                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        title: Text(q['text'].toString()),
                        subtitle: Text(
                          '${QuestionType.label(q['type']?.toString())} | الصعوبة: ${q['level']}${pdfPath.isNotEmpty ? ' | 📄 مرفق PDF' : ''}',
                        ),
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) async {
                            if (value == 'edit') {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => AddQuestionScreen(
                                    examId: widget.examId,
                                    existingQuestion: q,
                                  ),
                                ),
                              );
                              _loadQuestions();
                            } else if (value == 'delete') {
                              _deleteQuestion((q['id'] as num).toInt());
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'edit', child: Text('تعديل')),
                            PopupMenuItem(value: 'delete', child: Text('حذف')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.small(
            heroTag: 'import_pdf',
            tooltip: 'استخراج أسئلة من PDF',
            backgroundColor: Colors.red,
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PdfImportScreen(
                    examId: widget.examId,
                    examTitle: widget.examTitle,
                  ),
                ),
              );
              _loadQuestions();
            },
            child: const Icon(Icons.picture_as_pdf),
          ),
          const SizedBox(height: 12),
          FloatingActionButton(
            heroTag: 'add_question',
            tooltip: 'إضافة سؤال يدويًا',
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AddQuestionScreen(examId: widget.examId)),
              );
              _loadQuestions();
            },
            child: const Icon(Icons.add),
          ),
        ],
      ),
    );
  }
}
