import 'package:flutter/material.dart';

import '../../database/database_helper.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key});

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  int _examsCount = 0;
  int _questionsCount = 0;
  int _attemptsCount = 0;
  double _averageScore = 0;
  List<Map<String, dynamic>> _attempts = [];
  List<Map<String, dynamic>> _weakQuestions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    try {
      final exams = await DatabaseHelper.instance.getExams();
      final questionsCount = await DatabaseHelper.instance.getTotalQuestionsCount();
      final attemptsCount = await DatabaseHelper.instance.getAttemptsCount();
      final averageScore = await DatabaseHelper.instance.getAveragePercentage();
      final attempts = await DatabaseHelper.instance.getAttempts(limit: 20);
      final weakQuestions = await DatabaseHelper.instance.getWeakQuestions(limit: 8);

      if (!mounted) return;
      setState(() {
        _examsCount = exams.length;
        _questionsCount = questionsCount;
        _attemptsCount = attemptsCount;
        _averageScore = averageScore;
        _attempts = attempts;
        _weakQuestions = weakQuestions;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تحميل النتائج: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _openAttempt(int attemptId) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ResultDetailScreen(attemptId: attemptId),
      ),
    );
    _loadStats();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تحليل الأسئلة والنتائج')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadStats,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      Expanded(child: _statCard('الاختبارات', _examsCount, Icons.quiz, Colors.blue)),
                      const SizedBox(width: 10),
                      Expanded(child: _statCard('الأسئلة', _questionsCount, Icons.library_books, Colors.green)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(child: _statCard('المحاولات', _attemptsCount, Icons.assignment_turned_in, Colors.orange)),
                      const SizedBox(width: 10),
                      Expanded(child: _statCard('متوسط النتيجة', _averageScore.round(), Icons.analytics, Colors.purple, suffix: '%')),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'آخر النتائج',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  if (_attempts.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Text('لم يتم تنفيذ أي اختبار حتى الآن.'),
                      ),
                    )
                  else
                    ..._attempts.map((attempt) {
                      final percentage = (attempt['percentage'] as num).toDouble();
                      final correct = (attempt['correct_answers'] as num).toInt();
                      final total = (attempt['total_questions'] as num).toInt();
                      final attemptId = (attempt['id'] as num).toInt();
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            child: Text('${percentage.round()}%'),
                          ),
                          title: Text(attempt['exam_title'].toString()),
                          subtitle: Text('$correct / $total إجابات صحيحة'),
                          trailing: const Icon(Icons.chevron_left),
                          onTap: () => _openAttempt(attemptId),
                        ),
                      );
                    }),
                  const SizedBox(height: 24),
                  const Text(
                    'الأسئلة الأكثر أخطاءً',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  if (_weakQuestions.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Text('لا توجد بيانات كافية للتحليل. نفّذ اختبارًا واحدًا على الأقل.'),
                      ),
                    )
                  else
                    ..._weakQuestions.map((item) {
                      final rate = (item['error_rate'] as num).toDouble();
                      final wrong = (item['wrong_count'] as num).toInt();
                      final attempts = (item['attempts_count'] as num).toInt();
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: rate >= 50 ? Colors.red[100] : Colors.orange[100],
                            child: Text('${rate.round()}%'),
                          ),
                          title: Text(item['question_text'].toString()),
                          subtitle: Text('إجابات خاطئة: $wrong من أصل $attempts'),
                        ),
                      );
                    }),
                ],
              ),
            ),
    );
  }

  Widget _statCard(
    String title,
    int value,
    IconData icon,
    Color color, {
    String suffix = '',
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$value$suffix', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text(title, style: TextStyle(color: Colors.grey[700], fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ResultDetailScreen extends StatefulWidget {
  final int attemptId;

  const ResultDetailScreen({super.key, required this.attemptId});

  @override
  State<ResultDetailScreen> createState() => _ResultDetailScreenState();
}

class _ResultDetailScreenState extends State<ResultDetailScreen> {
  Map<String, dynamic>? _data;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await DatabaseHelper.instance.getAttempt(widget.attemptId);
    if (!mounted) return;
    setState(() {
      _data = data;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('نتيجة الاختبار')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_data == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('نتيجة الاختبار')),
        body: const Center(child: Text('لم يتم العثور على النتيجة.')),
      );
    }

    final attempt = _data!['attempt'] as Map<String, dynamic>;
    final answers = (_data!['answers'] as List).cast<Map<String, dynamic>>();
    final percentage = (attempt['percentage'] as num).toDouble();
    final correct = (attempt['correct_answers'] as num).toInt();
    final total = (attempt['total_questions'] as num).toInt();

    return Scaffold(
      appBar: AppBar(title: const Text('نتيجة الاختبار')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: Colors.blue[50],
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(attempt['exam_title'].toString(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  Text('${percentage.round()}%', style: const TextStyle(fontSize: 46, fontWeight: FontWeight.bold, color: Colors.blue)),
                  const SizedBox(height: 8),
                  Text('$correct من $total إجابات صحيحة'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text('تفصيل الإجابات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ...answers.asMap().entries.map((entry) {
            final index = entry.key;
            final item = entry.value;
            final isCorrect = item['is_correct'] == 1;
            return Card(
              child: ExpansionTile(
                leading: Icon(
                  isCorrect ? Icons.check_circle : Icons.cancel,
                  color: isCorrect ? Colors.green : Colors.red,
                ),
                title: Text('السؤال ${index + 1}'),
                subtitle: Text(isCorrect ? 'إجابة صحيحة' : 'إجابة خاطئة'),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                children: [
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text('السؤال: ${item['question_text']}'),
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text('إجابتك: ${item['selected_answer'].toString().isEmpty ? 'بدون إجابة' : item['selected_answer']}'),
                  ),
                  if (!isCorrect) ...[
                    const SizedBox(height: 8),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'الإجابة الصحيحة: ${item['correct_answer']}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
