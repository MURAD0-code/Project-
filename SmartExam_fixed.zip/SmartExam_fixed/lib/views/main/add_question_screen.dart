import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../../database/database_helper.dart';
import '../../models/question_types.dart';
import '../../utils/pdf_storage.dart';
import '../widgets/choice_tile.dart';

class AddQuestionScreen extends StatefulWidget {
  final int examId;
  final Map<String, dynamic>? existingQuestion;

  /// عند true لا يُحفظ السؤال في قاعدة البيانات، بل يُعاد كخريطة عبر
  /// Navigator.pop (يُستخدم لتعديل الأسئلة المستخرجة قبل حفظها).
  final bool returnDraft;

  const AddQuestionScreen({
    super.key,
    required this.examId,
    this.existingQuestion,
    this.returnDraft = false,
  });

  @override
  State<AddQuestionScreen> createState() => _AddQuestionScreenState();
}

class _AddQuestionScreenState extends State<AddQuestionScreen> {
  static const int _defaultOptionsCount = 4;

  final _textController = TextEditingController();
  final _answerController = TextEditingController();
  final List<TextEditingController> _optionControllers = [];
  final _formKey = GlobalKey<FormState>();

  String _type = QuestionType.text;
  String _level = 'سهل';
  int? _correctIndex;
  String? _tfAnswer;
  String? _pdfPath;
  bool _saving = false;

  bool get _isEditing => widget.existingQuestion != null;

  @override
  void initState() {
    super.initState();
    final q = widget.existingQuestion;
    var options = <String>[];
    var answer = '';

    if (q != null) {
      _textController.text = q['text']?.toString() ?? '';
      answer = q['answer']?.toString() ?? '';
      final level = q['level']?.toString() ?? 'سهل';
      _level = QuestionType.levels.contains(level) ? level : 'سهل';
      final path = q['pdf_path']?.toString() ?? '';
      _pdfPath = path.isEmpty ? null : path;
      _type = QuestionType.normalizeType(q['type']?.toString());
      options = QuestionType.parseOptions(q['options']);
    }

    final count = options.length > _defaultOptionsCount ? options.length : _defaultOptionsCount;
    for (var i = 0; i < count; i++) {
      _optionControllers.add(TextEditingController(text: i < options.length ? options[i] : ''));
    }

    if (_type == QuestionType.mcq) {
      final idx = options.indexWhere(
        (o) => DatabaseHelper.normalizeAnswer(o) == DatabaseHelper.normalizeAnswer(answer),
      );
      _correctIndex = idx >= 0 ? idx : null;
    } else if (_type == QuestionType.trueFalse) {
      _tfAnswer = (answer == QuestionType.trueLabel || answer == QuestionType.falseLabel) ? answer : null;
    } else {
      _answerController.text = answer;
    }
  }

  @override
  void dispose() {
    _textController.dispose();
    _answerController.dispose();
    for (final c in _optionControllers) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickPDF() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );
      if (result == null || result.files.single.path == null || !mounted) return;
      setState(() => _pdfPath = result.files.single.path);
    } catch (e) {
      _showError('تعذر اختيار ملف PDF: $e');
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _saving) return;

    final text = _textController.text.trim();
    var answer = '';
    var options = <String>[];

    if (_type == QuestionType.mcq) {
      int? correct;
      for (var i = 0; i < _optionControllers.length; i++) {
        final value = _optionControllers[i].text.trim();
        if (value.isEmpty) continue;
        if (_correctIndex == i) correct = options.length;
        options.add(value);
      }
      if (options.length < 2) {
        _showError('أدخل خيارين على الأقل.');
        return;
      }
      if (options.map(DatabaseHelper.normalizeAnswer).toSet().length != options.length) {
        _showError('يوجد خياران متطابقان، عدّل الخيارات.');
        return;
      }
      if (correct == null) {
        _showError('حدد الخيار الصحيح بالضغط على الدائرة بجانبه.');
        return;
      }
      answer = options[correct];
    } else if (_type == QuestionType.trueFalse) {
      if (_tfAnswer == null) {
        _showError('حدد هل العبارة صح أم خطأ.');
        return;
      }
      answer = _tfAnswer!;
    } else {
      answer = _answerController.text.trim();
    }

    if (widget.returnDraft) {
      Navigator.pop(context, <String, dynamic>{
        'text': text,
        'answer': answer,
        'level': _level,
        'type': _type,
        'options': options,
      });
      return;
    }

    setState(() => _saving = true);
    try {
      final rawPdf = _pdfPath?.trim();
      final pdfPath = (rawPdf == null || rawPdf.isEmpty) ? null : await PdfStorage.persist(rawPdf);
      int affected;

      if (_isEditing) {
        affected = await DatabaseHelper.instance.updateQuestion(
          (widget.existingQuestion!['id'] as num).toInt(),
          text,
          answer,
          _level,
          pdfPath,
          type: _type,
          options: options,
        );
      } else {
        affected = await DatabaseHelper.instance.addQuestion(
          widget.examId,
          text,
          answer,
          _level,
          pdfPath,
          type: _type,
          options: options,
        );
      }

      if (!mounted) return;
      setState(() => _saving = false);
      if (affected <= 0) {
        throw StateError('لم يتم حفظ السؤال.');
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_isEditing ? 'تم تعديل السؤال بنجاح' : 'تمت إضافة السؤال بنجاح'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      _showError('تعذر حفظ السؤال: $e');
    }
  }

  Widget _buildAnswerSection() {
    switch (_type) {
      case QuestionType.mcq:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'الخيارات (اضغط الدائرة لتحديد الخيار الصحيح)',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            for (var i = 0; i < _optionControllers.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  children: [
                    IconButton(
                      tooltip: 'الخيار الصحيح',
                      onPressed: _saving ? null : () => setState(() => _correctIndex = i),
                      icon: Icon(
                        _correctIndex == i ? Icons.check_circle : Icons.radio_button_unchecked,
                        color: _correctIndex == i ? Colors.green : Colors.grey,
                      ),
                    ),
                    Expanded(
                      child: TextFormField(
                        controller: _optionControllers[i],
                        decoration: InputDecoration(
                          labelText: 'الخيار ${i + 1}',
                          border: const OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        );
      case QuestionType.trueFalse:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('الإجابة الصحيحة', style: TextStyle(fontWeight: FontWeight.bold)),
            ChoiceTile(
              label: QuestionType.trueLabel,
              selected: _tfAnswer == QuestionType.trueLabel,
              onTap: _saving ? null : () => setState(() => _tfAnswer = QuestionType.trueLabel),
            ),
            ChoiceTile(
              label: QuestionType.falseLabel,
              selected: _tfAnswer == QuestionType.falseLabel,
              onTap: _saving ? null : () => setState(() => _tfAnswer = QuestionType.falseLabel),
            ),
          ],
        );
      default:
        return TextFormField(
          controller: _answerController,
          maxLines: 2,
          decoration: const InputDecoration(labelText: 'الإجابة الصحيحة', border: OutlineInputBorder()),
          validator: (value) => value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEditing ? 'تعديل السؤال' : 'إضافة سؤال جديد')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              DropdownButtonFormField<String>(
                initialValue: _type,
                items: [
                  for (final t in QuestionType.all)
                    DropdownMenuItem(value: t, child: Text(QuestionType.label(t))),
                ],
                onChanged: _saving ? null : (value) => setState(() => _type = value ?? QuestionType.text),
                decoration: const InputDecoration(labelText: 'نوع السؤال', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: _textController,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'نص السؤال', border: OutlineInputBorder()),
                validator: (value) => value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null,
              ),
              const SizedBox(height: 15),
              _buildAnswerSection(),
              const SizedBox(height: 15),
              DropdownButtonFormField<String>(
                initialValue: _level,
                items: [
                  for (final l in QuestionType.levels) DropdownMenuItem(value: l, child: Text(l)),
                ],
                onChanged: _saving ? null : (value) => setState(() => _level = value ?? 'سهل'),
                decoration: const InputDecoration(labelText: 'مستوى الصعوبة', border: OutlineInputBorder()),
              ),
              if (!widget.returnDraft) ...[
                const SizedBox(height: 15),
                OutlinedButton.icon(
                  onPressed: _saving ? null : _pickPDF,
                  icon: const Icon(Icons.picture_as_pdf, color: Colors.red),
                  label: Text(_pdfPath == null ? 'اختيار ملف PDF مرجعي' : 'تم اختيار ملف PDF'),
                ),
                if (_pdfPath != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Text(
                      'الملف: ${_pdfPath!.split(RegExp(r'[\\/]')).last}',
                      style: TextStyle(color: Colors.grey[700], fontSize: 12),
                    ),
                  ),
              ],
              const SizedBox(height: 25),
              ElevatedButton(
                onPressed: _saving ? null : _save,
                style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                child: _saving
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : Text(
                        widget.returnDraft
                            ? 'اعتماد التعديل'
                            : (_isEditing ? 'حفظ التعديلات' : 'حفظ السؤال في البنك'),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
