import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../../database/database_helper.dart';

class AddQuestionScreen extends StatefulWidget {
  final int examId;
  final Map<String, dynamic>? existingQuestion;

  const AddQuestionScreen({
    super.key,
    required this.examId,
    this.existingQuestion,
  });

  @override
  State<AddQuestionScreen> createState() => _AddQuestionScreenState();
}

class _AddQuestionScreenState extends State<AddQuestionScreen> {
  final _textController = TextEditingController();
  final _answerController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String _level = 'سهل';
  String? _pdfPath;
  bool _saving = false;

  bool get _isEditing => widget.existingQuestion != null;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      final q = widget.existingQuestion!;
      _textController.text = q['text']?.toString() ?? '';
      _answerController.text = q['answer']?.toString() ?? '';
      final level = q['level']?.toString() ?? 'سهل';
      _level = ['سهل', 'متوسط', 'صعب'].contains(level) ? level : 'سهل';
      final path = q['pdf_path']?.toString() ?? '';
      _pdfPath = path.isEmpty ? null : path;
    }
  }

  @override
  void dispose() {
    _textController.dispose();
    _answerController.dispose();
    super.dispose();
  }

  Future<void> _pickPDF() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );
      if (result == null || result.files.single.path == null || !mounted) return;
      setState(() => _pdfPath = result.files.single.path);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر اختيار ملف PDF: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _saving) return;
    setState(() => _saving = true);

    try {
      final text = _textController.text.trim();
      final answer = _answerController.text.trim();
      final pdfPath = _pdfPath?.trim();
      int affected;

      if (_isEditing) {
        affected = await DatabaseHelper.instance.updateQuestion(
          (widget.existingQuestion!['id'] as num).toInt(),
          text,
          answer,
          _level,
          pdfPath,
        );
      } else {
        affected = await DatabaseHelper.instance.addQuestion(
          widget.examId,
          text,
          answer,
          _level,
          pdfPath,
        );
      }

      if (!mounted) return;
      setState(() => _saving = false);
      if (affected <= 0) {
        throw StateError('لم يتم حفظ السؤال.');
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_isEditing ? 'تم تعديل السؤال بنجاح' : 'تمت إضافة السؤال بنجاح'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر حفظ السؤال: $e'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEditing ? 'تعديل السؤال' : 'إضافة سؤال جديد')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _textController,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'نص السؤال', border: OutlineInputBorder()),
                validator: (value) => value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null,
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: _answerController,
                maxLines: 2,
                decoration: const InputDecoration(labelText: 'الإجابة الصحيحة', border: OutlineInputBorder()),
                validator: (value) => value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null,
              ),
              const SizedBox(height: 15),
              DropdownButtonFormField<String>(
                value: _level,
                items: const [
                  DropdownMenuItem(value: 'سهل', child: Text('سهل')),
                  DropdownMenuItem(value: 'متوسط', child: Text('متوسط')),
                  DropdownMenuItem(value: 'صعب', child: Text('صعب')),
                ],
                onChanged: _saving ? null : (value) => setState(() => _level = value ?? 'سهل'),
                decoration: const InputDecoration(labelText: 'مستوى الصعوبة', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 15),
              OutlinedButton.icon(
                onPressed: _saving ? null : _pickPDF,
                icon: const Icon(Icons.picture_as_pdf, color: Colors.red),
                label: Text(_pdfPath == null ? 'اختيار ملف PDF مرجعي' : 'تم اختيار ملف PDF'),
              ),
              if (_pdfPath != null)
                Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Text(
                    'الملف: ${_pdfPath!.split(RegExp(r'[\\/]')).last}',
                    style: TextStyle(color: Colors.grey[700], fontSize: 12),
                  ),
                ),
              const SizedBox(height: 25),
              ElevatedButton(
                onPressed: _saving ? null : _save,
                style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                child: _saving
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : Text(_isEditing ? 'حفظ التعديلات' : 'حفظ السؤال في البنك'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
