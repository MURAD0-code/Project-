import 'package:flutter/material.dart';

import '../../database/database_helper.dart';
import '../../services/auth_service.dart';
import '../auth/auth_screens.dart';
import 'exam_generator_screen.dart';
import 'question_bank_screen.dart';
import 'results_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _examsCount = 0;
  int _questionsCount = 0;
  int _attemptsCount = 0;
  double _averageScore = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    try {
      final exams = await DatabaseHelper.instance.getExams();
      final questions = await DatabaseHelper.instance.getTotalQuestionsCount();
      final attempts = await DatabaseHelper.instance.getAttemptsCount();
      final average = await DatabaseHelper.instance.getAveragePercentage();
      if (!mounted) return;
      setState(() {
        _examsCount = exams.length;
        _questionsCount = questions;
        _attemptsCount = attempts;
        _averageScore = average;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تحميل الإحصائيات: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _open(Widget screen) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
    _loadStats();
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل تريد تسجيل الخروج والعودة إلى شاشة الدخول؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('خروج')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    await AuthService.instance.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة التحكم - SmartExam'),
        centerTitle: true,
        actions: [
          IconButton(onPressed: _loadStats, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadStats,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 34,
                            backgroundColor: Colors.blue[100],
                            child: Icon(Icons.school, size: 38, color: Colors.blue[800]),
                          ),
                          const SizedBox(width: 14),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('أهلًا بك في SmartExam', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                                SizedBox(height: 4),
                                Text('نظام إدارة وتوليد الاختبارات محليًا'),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 1.8,
                    children: [
                      _statCard('الاختبارات', _examsCount.toString(), Icons.quiz, Colors.blue),
                      _statCard('الأسئلة', _questionsCount.toString(), Icons.library_books, Colors.green),
                      _statCard('المحاولات', _attemptsCount.toString(), Icons.assignment_turned_in, Colors.orange),
                      _statCard('متوسط النتيجة', '${_averageScore.round()}%', Icons.analytics, Colors.purple),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const Text('الأقسام الرئيسية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  _sectionCard(
                    title: 'بنك الاختبارات والأسئلة',
                    subtitle: 'إضافة وتعديل وحذف الاختبارات والأسئلة',
                    icon: Icons.library_books,
                    color: Colors.blue,
                    onTap: () => _open(const QuestionBankScreen()),
                  ),
                  _sectionCard(
                    title: 'توليد اختبار تلقائي',
                    subtitle: 'اختيار أسئلة عشوائية ثم حلها وتصحيحها',
                    icon: Icons.auto_awesome,
                    color: Colors.orange,
                    onTap: () => _open(const ExamGeneratorScreen()),
                  ),
                  _sectionCard(
                    title: 'تحليل الأسئلة والنتائج',
                    subtitle: 'عرض المحاولات والدرجات والأسئلة الأكثر أخطاءً',
                    icon: Icons.analytics,
                    color: Colors.green,
                    onTap: () => _open(const ResultsScreen()),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _statCard(String title, String value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  Text(title, style: TextStyle(color: Colors.grey[700], fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        contentPadding: const EdgeInsets.all(12),
        leading: CircleAvatar(
          backgroundColor: color.withValues(alpha: 0.12),
          child: Icon(icon, color: color),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_left),
        onTap: onTap,
      ),
    );
  }
}
