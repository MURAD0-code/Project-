import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../../database/database_helper.dart';
import '../../models/question_types.dart';
import '../../services/gemini_service.dart';
import '../../utils/pdf_storage.dart';
import 'add_question_screen.dart';

enum _Stage { pick, processing, review }

/// استخراج أسئلة من ملف PDF (محاضرة أو ملف أسئلة جاهز) وحفظها في بنك الأسئلة.
class PdfImportScreen extends StatefulWidget {
  final int examId;
  final String examTitle;

  const PdfImportScreen({
    super.key,
    required this.examId,
    required this.examTitle,
  });

  @override
  State<PdfImportScreen> createState() => _PdfImportScreenState();
}

class _PdfImportScreenState extends State<PdfImportScreen> {
  _Stage _stage = _Stage.pick;
  int _lectureCount = 10;
  String? _pdfPath;
  String? _pdfName;
  ExtractionResult? _result;
  final List<Map<String, dynamic>> _items = [];
  final Set<int> _selected = {};
  bool _saving = false;
  bool _allowExit = false;

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  /// يعرض نافذة إدخال/حذف المفتاح. يعيد true إذا أصبح هناك مفتاح محفوظ.
  Future<bool> _showKeyDialog() async {
    final existing = await GeminiService.instance.getApiKey();
    if (!mounted) return false;
    final controller = TextEditingController();

    try {
      final action = await showDialog<String>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('مفتاح Gemini API'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('استخراج الأسئلة يحتاج مفتاح Gemini API خاصًا بك. يمكنك إنشاؤه مجانًا من:'),
                const SizedBox(height: 6),
                const SelectableText(
                  'aistudio.google.com/apikey',
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: Colors.blue),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: controller,
                  obscureText: true,
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(
                    labelText: existing == null ? 'الصق المفتاح هنا' : 'مفتاح جديد (يستبدل المحفوظ)',
                    border: const OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'يُحفظ المفتاح مشفرًا على هذا الجهاز فقط. عند الاستخراج يُرسل ملف الـ PDF إلى خدمة Google Gemini.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
          ),
          actions: [
            if (existing != null)
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, 'delete'),
                child: const Text('حذف المفتاح', style: TextStyle(color: Colors.red)),
              ),
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext, 'save'),
              child: const Text('حفظ'),
            ),
          ],
        ),
      );

      if (action == 'delete') {
        await GeminiService.instance.deleteApiKey();
        return false;
      }
      if (action == 'save') {
        final value = controller.text.trim();
        if (value.isEmpty) {
          _showError('لم تُدخل أي مفتاح.');
          return existing != null;
        }
        await GeminiService.instance.saveApiKey(value);
        return true;
      }
      return existing != null;
    } finally {
      controller.dispose();
    }
  }

  Future<bool> _ensureApiKey() async {
    if (await GeminiService.instance.getApiKey() != null) return true;
    return _showKeyDialog();
  }

  Future<void> _pickAndExtract() async {
    if (!await _ensureApiKey() || !mounted) return;

    String path;
    try {
      final picked = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );
      if (picked == null || picked.files.single.path == null || !mounted) return;
      path = picked.files.single.path!;
    } catch (e) {
      _showError('تعذر اختيار ملف PDF: $e');
      return;
    }

    setState(() {
      _stage = _Stage.processing;
      _pdfPath = path;
      _pdfName = p.basename(path);
    });

    try {
      final result = await GeminiService.instance.extractFromPdf(
        pdf: File(path),
        lectureQuestionCount: _lectureCount,
      );
      if (!mounted) return;
      setState(() {
        _result = result;
        _items
          ..clear()
          ..addAll(result.questions.map((q) => {
                ...q.toMap(),
                'answer_from_document': q.answerFromDocument,
              }));
        _selected
          ..clear()
          ..addAll(List.generate(_items.length, (i) => i));
        _stage = _Stage.review;
      });
    } on GeminiException catch (e) {
      if (!mounted) return;
      setState(() => _stage = _Stage.pick);
      _showError(e.message);
    } catch (e) {
      if (!mounted) return;
      setState(() => _stage = _Stage.pick);
      _showError('حدث خطأ أثناء الاستخراج: $e');
    }
  }

  Future<void> _editItem(int index) async {
    final draft = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(
        builder: (_) => AddQuestionScreen(
          examId: widget.examId,
          existingQuestion: _items[index],
          returnDraft: true,
        ),
      ),
    );
    if (draft == null || !mounted) return;
    setState(() {
      // بعد مراجعة المستخدم واعتماده لم نعد نعرض تحذير "إجابة مقترحة"
      _items[index] = {..._items[index], ...draft, 'answer_from_document': true};
    });
  }

  Future<void> _saveSelected() async {
    if (_selected.isEmpty || _saving || _pdfPath == null) return;
    setState(() => _saving = true);

    try {
      final persistedPdf = await PdfStorage.persist(_pdfPath!);
      final indexes = _selected.toList()..sort();
      final toSave = [
        for (final i in indexes) {..._items[i], 'pdf_path': persistedPdf},
      ];
      final outcome = await DatabaseHelper.instance.addQuestionsBatch(widget.examId, toSave);

      if (!mounted) return;
      final inserted = outcome['inserted'] ?? 0;
      final duplicates = outcome['duplicates'] ?? 0;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            duplicates > 0
                ? 'تم حفظ $inserted سؤال وتجاهل $duplicates سؤال مكرر'
                : 'تم حفظ $inserted سؤال في بنك الأسئلة',
          ),
          backgroundColor: Colors.green,
        ),
      );
      setState(() {
        _saving = false;
        _allowExit = true;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) Navigator.of(context).pop(true);
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      _showError('تعذر حفظ الأسئلة: $e');
    }
  }

  Future<void> _confirmExit() async {
    final leave = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('الخروج بدون حفظ؟'),
        content: const Text('الأسئلة المستخرجة لم تُحفظ بعد وستضيع إذا خرجت.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('البقاء')),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('خروج', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (leave != true || !mounted) return;
    setState(() => _allowExit = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) Navigator.of(context).maybePop();
    });
  }

  @override
  Widget build(BuildContext context) {
    final inReview = _stage == _Stage.review;
    return PopScope(
      canPop: _allowExit || !inReview,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmExit();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('استخراج أسئلة من PDF'),
          actions: [
            IconButton(
              tooltip: 'مفتاح Gemini',
              icon: const Icon(Icons.key),
              onPressed: (_stage == _Stage.processing || _saving) ? null : _showKeyDialog,
            ),
          ],
        ),
        body: switch (_stage) {
          _Stage.pick => _buildPick(),
          _Stage.processing => _buildProcessing(),
          _Stage.review => _buildReview(),
        },
        bottomNavigationBar: inReview ? _buildSaveBar() : null,
      ),
    );
  }

  Widget _buildPick() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 10),
          const Icon(Icons.picture_as_pdf, size: 72, color: Colors.red),
          const SizedBox(height: 12),
          Text(
            'الاختبار: ${widget.examTitle}',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          const Text(
            'اختر ملف PDF:\n'
            '• إذا كان محاضرة: سيتم توليد أسئلة منها.\n'
            '• إذا كان يحتوي أسئلة جاهزة: سيتم استخراجها كما هي.\n'
            'ستراجع الأسئلة قبل حفظها في البنك.',
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<int>(
            initialValue: _lectureCount,
            items: const [5, 10, 15, 20, 30]
                .map((n) => DropdownMenuItem(value: n, child: Text('$n سؤال')))
                .toList(),
            onChanged: (value) => setState(() => _lectureCount = value ?? 10),
            decoration: const InputDecoration(
              labelText: 'عدد الأسئلة (يُستخدم فقط إذا كان الملف محاضرة)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: _pickAndExtract,
            icon: const Icon(Icons.upload_file),
            label: const Text('اختيار ملف PDF واستخراج الأسئلة'),
            style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 52)),
          ),
          const SizedBox(height: 12),
          const Text(
            'الحد الأقصى لحجم الملف 20 ميجابايت. يُرسل الملف إلى Google Gemini للمعالجة.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildProcessing() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 20),
            const Text('جاري قراءة الملف واستخراج الأسئلة...', style: TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text(
              _pdfName ?? '',
              textDirection: TextDirection.ltr,
              style: const TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 8),
            const Text('قد يستغرق هذا حتى دقيقة أو أكثر للملفات الكبيرة.', style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _buildReview() {
    final result = _result!;
    final unverified = _items.where((q) => q['answer_from_document'] == false).length;
    final allSelected = _selected.length == _items.length;

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          color: Colors.blue[50],
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  result.sourceType == 'questions'
                      ? 'الملف يحتوي أسئلة جاهزة — تم استخراج ${_items.length} سؤال'
                      : 'الملف محاضرة — تم توليد ${_items.length} سؤال',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                if (unverified > 0)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      '$unverified سؤال لا توجد إجابته في الملف، والإجابة المعروضة اقتراح من النموذج. راجعها قبل الحفظ.',
                      style: const TextStyle(color: Colors.deepOrange),
                    ),
                  ),
                if (result.skipped > 0)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      'تم تجاهل ${result.skipped} سؤال لأن بياناته غير صالحة.',
                      style: TextStyle(color: Colors.grey[700]),
                    ),
                  ),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: TextButton(
                    onPressed: () => setState(() {
                      if (allSelected) {
                        _selected.clear();
                      } else {
                        _selected
                          ..clear()
                          ..addAll(List.generate(_items.length, (i) => i));
                      }
                    }),
                    child: Text(allSelected ? 'إلغاء تحديد الكل' : 'تحديد الكل'),
                  ),
                ),
              ],
            ),
          ),
        ),
        for (var i = 0; i < _items.length; i++) _buildItemCard(i),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildItemCard(int index) {
    final q = _items[index];
    final type = q['type'].toString();
    final answer = q['answer'].toString();
    final options = QuestionType.parseOptions(q['options']);
    final selected = _selected.contains(index);

    return Card(
      margin: const EdgeInsets.only(top: 8),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Checkbox(
                  value: selected,
                  onChanged: (value) => setState(() {
                    if (value == true) {
                      _selected.add(index);
                    } else {
                      _selected.remove(index);
                    }
                  }),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      '${index + 1}. ${q['text']}',
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'تعديل',
                  icon: const Icon(Icons.edit, size: 20),
                  onPressed: () => _editItem(index),
                ),
              ],
            ),
            Wrap(
              spacing: 6,
              children: [
                Chip(
                  label: Text(QuestionType.label(type), style: const TextStyle(fontSize: 12)),
                  visualDensity: VisualDensity.compact,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                Chip(
                  label: Text(q['level'].toString(), style: const TextStyle(fontSize: 12)),
                  visualDensity: VisualDensity.compact,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
              ],
            ),
            const SizedBox(height: 6),
            if (type == QuestionType.mcq && options.isNotEmpty)
              for (final option in options)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    children: [
                      Icon(
                        option == answer ? Icons.check_circle : Icons.circle_outlined,
                        size: 18,
                        color: option == answer ? Colors.green : Colors.grey,
                      ),
                      const SizedBox(width: 6),
                      Expanded(child: Text(option)),
                    ],
                  ),
                )
            else
              Text('الإجابة: $answer', style: const TextStyle(color: Colors.green)),
            if (q['answer_from_document'] == false)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Row(
                  children: [
                    Icon(Icons.warning_amber, size: 18, color: Colors.deepOrange),
                    SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'الإجابة اقتراح من النموذج وليست من الملف',
                        style: TextStyle(color: Colors.deepOrange, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSaveBar() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: ElevatedButton.icon(
          onPressed: (_selected.isEmpty || _saving) ? null : _saveSelected,
          icon: _saving
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                )
              : const Icon(Icons.save),
          label: Text('حفظ المحدد (${_selected.length}) في بنك الأسئلة'),
          style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 52)),
        ),
      ),
    );
  }
}
