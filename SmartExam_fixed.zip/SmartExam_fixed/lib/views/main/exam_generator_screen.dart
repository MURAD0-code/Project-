import 'package:flutter/material.dart';

import '../../database/database_helper.dart';
import 'exam_taking_screen.dart';

class ExamGeneratorScreen extends StatefulWidget {
  const ExamGeneratorScreen({super.key});

  @override
  State<ExamGeneratorScreen> createState() => _ExamGeneratorScreenState();
}

class _ExamGeneratorScreenState extends State<ExamGeneratorScreen> {
  List<Map<String, dynamic>> _exams = [];
  int? _selectedExamId;
  int _availableQuestions = 0;
  int _questionCount = 1;
  bool _loading = true;
  bool _generating = false;

  @override
  void initState() {
    super.initState();
    _loadExams();
  }

  Future<void> _loadExams() async {
    try {
      final exams = await DatabaseHelper.instance.getExams();
      if (!mounted) return;
      setState(() {
        _exams = exams;
        _selectedExamId = exams.isEmpty ? null : (exams.first['id'] as num).toInt();
        _loading = false;
      });
      if (_selectedExamId != null) {
        await _loadQuestionCount(_selectedExamId!);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      _showError('تعذر تحميل الاختبارات: $e');
    }
  }

  Future<void> _loadQuestionCount(int examId) async {
    try {
      final count = await DatabaseHelper.instance.getQuestionCountForExam(examId);
      if (!mounted) return;
      setState(() {
        _availableQuestions = count;
        _questionCount = count == 0 ? 1 : _questionCount.clamp(1, count).toInt();
        if (count > 0 && _questionCount > count) {
          _questionCount = count;
        }
      });
    } catch (e) {
      if (!mounted) return;
      _showError('تعذر قراءة عدد الأسئلة: $e');
    }
  }

  Future<void> _generateExam() async {
    final examId = _selectedExamId;
    if (examId == null) {
      _showError('أضف اختبارًا أولًا من بنك الاختبارات.');
      return;
    }

    if (_availableQuestions == 0) {
      _showError('لا توجد أسئلة في هذا الاختبار. أضف أسئلة أولًا.');
      return;
    }

    if (_questionCount > _availableQuestions) {
      _showError('المتاح $_availableQuestions سؤالًا فقط، ولا يمكن توليد $_questionCount سؤالًا.');
      return;
    }

    setState(() => _generating = true);
    try {
      final questions = await DatabaseHelper.instance.getRandomQuestions(
        examId,
        _questionCount,
      );

      if (questions.length != _questionCount) {
        throw StateError('لم يتم الحصول على العدد المطلوب من الأسئلة.');
      }

      final exam = _exams.firstWhere(
        (item) => (item['id'] as num).toInt() == examId,
      );

      if (!mounted) return;
      setState(() => _generating = false);
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ExamTakingScreen(
            examId: examId,
            examTitle: exam['title'].toString(),
            questions: questions,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _generating = false);
      _showError('تعذر توليد الاختبار: $e');
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('مولد الاختبارات التلقائي')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_exams.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('مولد الاختبارات التلقائي')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'لا توجد اختبارات. اذهب إلى بنك الاختبارات وأنشئ اختبارًا ثم أضف إليه أسئلة.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    final int maxQuestions = _availableQuestions.clamp(1, 100).toInt();

    return Scaffold(
      appBar: AppBar(title: const Text('مولد الاختبارات التلقائي')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.auto_awesome, size: 60, color: Colors.blue),
                    const SizedBox(height: 15),
                    const Text(
                      'اختيار الاختبار',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<int>(
                      value: _selectedExamId,
                      decoration: const InputDecoration(
                        labelText: 'الاختبار',
                        border: OutlineInputBorder(),
                      ),
                      items: _exams.map((exam) {
                        final id = (exam['id'] as num).toInt();
                        return DropdownMenuItem<int>(
                          value: id,
                          child: Text(exam['title'].toString()),
                        );
                      }).toList(),
                      onChanged: (value) async {
                        if (value == null) return;
                        setState(() => _selectedExamId = value);
                        await _loadQuestionCount(value);
                      },
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'الأسئلة المتاحة: $_availableQuestions',
                      style: TextStyle(color: Colors.grey[700]),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '$_questionCount سؤال',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.blue),
                    ),
                    Slider(
                      value: _questionCount.toDouble().clamp(1, maxQuestions.toDouble()).toDouble(),
                      min: 1,
                      max: maxQuestions.toDouble(),
                      divisions: maxQuestions > 1 ? maxQuestions - 1 : 1,
                      label: _questionCount.toString(),
                      onChanged: _availableQuestions <= 0
                          ? null
                          : (value) => setState(() => _questionCount = value.round()),
                    ),
                    const Text(
                      'سيتم اختيار الأسئلة عشوائيًا من بنك الاختبار.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 25),
            ElevatedButton.icon(
              onPressed: _generating ? null : _generateExam,
              icon: _generating
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.flash_on),
              label: Text(_generating ? 'جاري التوليد...' : 'توليد الاختبار الآن'),
              style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 52)),
            ),
          ],
        ),
      ),
    );
  }
}
