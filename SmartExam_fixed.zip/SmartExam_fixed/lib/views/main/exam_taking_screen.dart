import 'package:flutter/material.dart';

import '../../database/database_helper.dart';
import 'results_screen.dart';

class ExamTakingScreen extends StatefulWidget {
  final int examId;
  final String examTitle;
  final List<Map<String, dynamic>> questions;

  const ExamTakingScreen({
    super.key,
    required this.examId,
    required this.examTitle,
    required this.questions,
  });

  @override
  State<ExamTakingScreen> createState() => _ExamTakingScreenState();
}

class _ExamTakingScreenState extends State<ExamTakingScreen> {
  late final List<TextEditingController> _controllers;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _controllers = List.generate(
      widget.questions.length,
      (_) => TextEditingController(),
    );
  }

  @override
  void dispose() {
    for (final controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _submitExam() async {
    if (_submitting) return;

    final unanswered = _controllers.where((controller) => controller.text.trim().isEmpty).length;
    final shouldSubmit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تسليم الاختبار'),
        content: Text(
          unanswered == 0
              ? 'هل أنت متأكد من تسليم الاختبار؟ سيتم تصحيح الإجابات مباشرة.'
              : 'يوجد $unanswered سؤال بدون إجابة. الأسئلة الفارغة ستُحسب إجابات خاطئة. هل تريد المتابعة؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('تسليم'),
          ),
        ],
      ),
    );

    if (shouldSubmit != true || !mounted) return;

    setState(() => _submitting = true);
    try {
      final answers = <int, String>{};
      for (var i = 0; i < widget.questions.length; i++) {
        final id = (widget.questions[i]['id'] as num).toInt();
        answers[id] = _controllers[i].text;
      }

      final attemptId = await DatabaseHelper.instance.saveAttempt(
        examId: widget.examId,
        examTitle: widget.examTitle,
        questions: widget.questions,
        answers: answers,
      );

      if (!mounted) return;
      setState(() => _submitting = false);
      await Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultDetailScreen(attemptId: attemptId),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _submitting = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر حفظ النتيجة: $e'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_submitting,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.examTitle),
          centerTitle: true,
        ),
        body: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: widget.questions.length + 1,
          itemBuilder: (context, index) {
            if (index == widget.questions.length) {
              return Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 30),
                child: ElevatedButton.icon(
                  onPressed: _submitting ? null : _submitExam,
                  icon: const Icon(Icons.done_all),
                  label: const Text('تسليم الاختبار وتصحيح الإجابات'),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 52),
                  ),
                ),
              );
            }

            final question = widget.questions[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 14),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'السؤال ${index + 1} من ${widget.questions.length}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      question['text'].toString(),
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _controllers[index],
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(
                        labelText: 'اكتب إجابتك',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
